package com.company;

public class Constants {

        public static String DRIVERPATH = "C:\\Users\\aparn\\Downloads\\testAutomation\\Input\\chromedriver.exe";
        public static String URL = "http://automationpractice.com/index.php";
        public static String EMAIL = "wnd12526@bcaoo.com";

        public static String FIRSTNAME = "TEST-USERNAME";
        public static String LASTNAME = "TEST-LASTNAME";
        public static String PASSWORD = "TEST-PASSWORD";
        public static String COMPANY = "TEST-COMPANY";
        public static String ADDRESS1 = "TEST-ADDRESS1";
        public static String ADDRESS2 = "TEST-ADDRESS2";
        public static String CITY = "TEST-CITY";
        public static String ZIPCODE = "12345";
        public static String ADDITIONAlINFORMATION = "TEST-ADDITIONAL-INFORMATION";
        public static String HOMEPHONE = "9876543210";
        public static String MOBILEPHONE = "0225024397";
        public static String ADDRESSALIAS = "TEST-ADDRESS-ALIAS";

        //for select fields
        public static String DATE = "1";
        public static String MONTH = "January";
        public static String YEAR = "1993";
        public static String STATE = "Alaska";
        public static String COUNTRY = "UNITED STATES";

}
